//const getPublicRepositories = async () => {
  //  console.log('get public repositories');
  //  const apiKey = "(aca va la apikey de cada uno de ustedes)...";
    // const inputVal = 524901;
    
    // datos para Curuzu Cuatia:
   // const lat = -29.7881054701491948;
   // const long = -58.08565404601809;
   // const baseUrl = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${long}&appid=${apiKey}&units=metric`;
    
   // const response = await fetch(`${baseUrl}`);
    //const jsonResponse = await response.json();
    //console.log(jsonResponse);
   // console.log(jsonResponse.city.name);
    // console.log(jsonResponse.city.name.list[0].main);
   // return jsonResponse[0];
   // };
    
    
    //api.openweathermap.org/data/2.5/forecast?id=524901&appid={API key}
    
    //const buscarPronostico = async () => {
    //const profileData = await getPublicRepositories();
    
    //};










    //CÒDIGO
const form = document.querySelector(".top-banner form");
const input = document.querySelector(".top-banner input");
const msg = document.querySelector(".top-banner .msg");
const list = document.querySelector(".ajax-section .cities");
/*SUBSCRIBE API KEY: https://home.openweathermap.org/users/sign_up*/
const apiKey = "66347cc4f3c928cf4f8651fbad8bc589";

form.addEventListener("submit", e => {
  e.preventDefault();
  let inputVal = input.value;

  //check if there's already a city
  const listItems = list.querySelectorAll(".ajax-section .city");
  const listItemsArray = Array.from(listItems);

  if (listItemsArray.length > 0) {
    const filteredArray = listItemsArray.filter(el => {
      let content = "";
    
      if (inputVal.includes(",")) {
        if (inputVal.split(",")[1].length > 2) {
          inputVal = inputVal.split(",")[0];
          content = el
            .querySelector(".city-name span")
            .textContent.toLowerCase();
        } else {
          content = el.querySelector(".city-name").dataset.name.toLowerCase();
        }
      } else {
        content = el.querySelector(".city-name span").textContent.toLowerCase();
      }
      return content == inputVal.toLowerCase();
    });

    if (filteredArray.length > 0) {
      msg.textContent = `Ya sabes el clima para ${
        filteredArray[0].querySelector(".city-name span").textContent
      } ...De lo contrario, sea màs especìfico y tambièn proporcione el còdigo del paìs 😉`;
      form.reset();
      input.focus();
      return;
    }
  }

  //ajax here
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${inputVal}&appid=${apiKey}&units=metric`;

  fetch(url)
    .then(response => response.json())
    .then(data => {
      const { main, name, sys, weather } = data;
      const icon = `https://s3-us-west-2.amazonaws.com/s.cdpn.io/162656/${
        weather[0]["icon"]
      }.svg`;

      const li = document.createElement("li");
      li.classList.add("city");
      const markup = `
        <h2 class="city-name" data-name="${name},${sys.country}">
          <span>${name}</span>
          <sup>${sys.country}</sup>
        </h2>
        <div class="city-temp">${Math.round(main.temp)}<sup>°C</sup></div>
        <figure>
          <img class="city-icon" src="${icon}" >
        </figure>
    `;
    li.innerHTML = markup;
    list.appendChild(li);
  })
  .catch(() => {
    msg.textContent = "Por favor escribe una ciudad vàlida 😩";
  });

msg.textContent = "";
form.reset();
input.focus();
});